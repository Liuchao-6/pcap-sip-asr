#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PAYLOAD="${PACKAGE_DIR}/payload/cpython-3.10.21+20260901-x86_64-unknown-linux-gnu-install_only.tar.gz"
PREFIX="/opt/python-3.10.21"
LINK_DIR="/usr/local/bin"
CREATE_LINKS=1
REPLACE=0

usage() {
  cat <<'EOF'
Usage: bash install.sh [options]

Options:
  --prefix DIR      Installation directory (default: /opt/python-3.10.21)
  --link-dir DIR    Versioned command link directory (default: /usr/local/bin)
  --no-links        Do not create python3.10 and pip3.10 command links
  --replace         Replace an existing installation after making a backup
  -h, --help        Show this help
EOF
}

while (($#)); do
  case "$1" in
    --prefix)
      [[ $# -ge 2 ]] || { echo "ERROR: --prefix requires a value" >&2; exit 2; }
      PREFIX=$2
      shift 2
      ;;
    --link-dir)
      [[ $# -ge 2 ]] || { echo "ERROR: --link-dir requires a value" >&2; exit 2; }
      LINK_DIR=$2
      shift 2
      ;;
    --no-links)
      CREATE_LINKS=0
      shift
      ;;
    --replace)
      REPLACE=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "ERROR: unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

[[ "$PREFIX" == /* && "$PREFIX" != "/" ]] || {
  echo "ERROR: --prefix must be an absolute path other than /" >&2
  exit 2
}
[[ "$LINK_DIR" == /* && "$LINK_DIR" != "/" ]] || {
  echo "ERROR: --link-dir must be an absolute path other than /" >&2
  exit 2
}

bash "${PACKAGE_DIR}/verify.sh"

parent=$(dirname -- "$PREFIX")
install -d "$parent"
work_dir=$(mktemp -d "${parent}/.python-3.10-install.XXXXXX")
cleanup() {
  rm -rf -- "$work_dir"
}
trap cleanup EXIT

tar -xzf "$PAYLOAD" -C "$work_dir"
[[ -x "${work_dir}/python/bin/python3.10" ]] || {
  echo "ERROR: extracted payload does not contain python/bin/python3.10" >&2
  exit 1
}

backup=""
if [[ -e "$PREFIX" || -L "$PREFIX" ]]; then
  if ((REPLACE == 0)); then
    echo "ERROR: $PREFIX already exists; use --replace to replace it" >&2
    exit 1
  fi
  backup="${PREFIX}.backup.$(date +%Y%m%d%H%M%S)"
  mv -- "$PREFIX" "$backup"
  echo "Existing installation moved to: $backup"
fi

if ! mv -- "${work_dir}/python" "$PREFIX"; then
  if [[ -n "$backup" && ! -e "$PREFIX" ]]; then
    mv -- "$backup" "$PREFIX"
  fi
  exit 1
fi

if ! "$PREFIX/bin/python3.10" - <<'PY'
import bz2
import ctypes
import hashlib
import lzma
import sqlite3
import ssl
import zlib

print("Python runtime check: OK")
print(ssl.OPENSSL_VERSION)
PY
then
  failed="${PREFIX}.failed.$(date +%Y%m%d%H%M%S)"
  mv -- "$PREFIX" "$failed"
  if [[ -n "$backup" ]]; then
    mv -- "$backup" "$PREFIX"
  fi
  echo "ERROR: runtime check failed; failed files kept at $failed" >&2
  exit 1
fi

if ((CREATE_LINKS == 1)); then
  install -d "$LINK_DIR"
  for name in python3.10 pip3.10; do
    destination="${LINK_DIR}/${name}"
    if [[ -e "$destination" && ! -L "$destination" ]]; then
      echo "ERROR: refusing to overwrite regular file: $destination" >&2
      exit 1
    fi
    ln -sfn -- "${PREFIX}/bin/${name}" "$destination"
  done
fi

echo
echo "Installed Python 3.10.21 to: $PREFIX"
"$PREFIX/bin/python3.10" --version
"$PREFIX/bin/python3.10" -m pip --version
if ((CREATE_LINKS == 1)); then
  echo "Command links: ${LINK_DIR}/python3.10 and ${LINK_DIR}/pip3.10"
fi

