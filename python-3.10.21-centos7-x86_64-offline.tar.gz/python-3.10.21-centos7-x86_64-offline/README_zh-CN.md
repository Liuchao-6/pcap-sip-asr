# Python 3.10.21 CentOS 7.9 x86_64 离线安装包

本目录用于在无法联网的 CentOS 7.9 x86_64 服务器上安装独立的 Python 3.10.21。安装不会替换系统自带的 `/usr/bin/python`，也不会修改 `yum` 使用的 Python 2.7。

## 包内容

- `payload/`：Python 3.10.21 独立运行时原始归档，包含 pip 26.2.1。
- `SHA256SUMS`：运行时 payload 的 SHA-256 校验值。
- `verify.sh`：检查 Linux、x86_64、glibc 版本和归档完整性。
- `install.sh`：安装运行时并执行标准库自检。
- `SOURCE.txt`：上游来源、版本和兼容性记录。

该运行时只要求基线 x86_64 指令集，不使用 `x86_64_v2/v3/v4` 构建。已静态检查主程序、`libpython` 和动态扩展，最高 glibc 符号版本为 `GLIBC_2.17`；CentOS 7.9 的 glibc 版本正是 2.17。

## 安装

把整个归档复制到 CentOS 7.9 服务器后执行：

```bash
tar -xzf python-3.10.21-centos7-x86_64-offline.tar.gz
cd python-3.10.21-centos7-x86_64-offline
sudo bash install.sh
```

默认安装到 `/opt/python-3.10.21`，并创建以下版本化命令链接：

```text
/usr/local/bin/python3.10
/usr/local/bin/pip3.10
```

安装后检查：

```bash
python3.10 --version
python3.10 -c "import ssl, sqlite3, ctypes, bz2, lzma, zlib; print('OK')"
python3.10 -m pip --version
```

## 自定义安装位置

安装到其他目录且不创建系统命令链接：

```bash
bash install.sh --prefix /data/python-3.10.21 --no-links
```

使用时通过完整路径调用，或只在当前 shell 设置 PATH：

```bash
export PATH=/data/python-3.10.21/bin:$PATH
python3.10 --version
```

若目标目录已存在，安装器默认停止。确认需要替换时使用 `--replace`；旧目录会改名为带时间戳的备份，不会直接删除。

## 完全离线安装第三方包

本包包含 pip，但不包含业务项目的第三方 wheels。提前在可联网机器准备与 Linux x86_64、Python 3.10 匹配的 wheel 目录，然后复制到服务器：

```bash
python3.10 -m pip install --no-index --find-links /path/to/wheels package_name
```

不要在 CentOS 7 上离线安装只提供源码包、却缺少本地编译依赖的软件包。

## 卸载

先确认路径无误，再执行：

```bash
sudo rm /usr/local/bin/python3.10 /usr/local/bin/pip3.10
sudo rm -rf /opt/python-3.10.21
```

如果安装时使用了自定义 `--prefix` 或 `--link-dir`，请对应修改路径。

## 验证边界

- 已验证：上游归档 SHA-256；payload 必需文件；主程序、`libpython` 和动态扩展的 glibc 符号上限为 2.17。
- 待验证：本机 Docker/WSL Linux 后端不可用，因此尚未在真实 CentOS 7.9 中执行安装器和运行时自检。
- CentOS 7 已停止官方维护。生产环境使用前，建议在同版本测试机执行 `bash verify.sh` 和完整业务回归。

