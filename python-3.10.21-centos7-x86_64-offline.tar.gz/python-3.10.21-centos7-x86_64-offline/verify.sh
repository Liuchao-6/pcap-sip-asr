#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$PACKAGE_DIR"

if [[ "$(uname -s)" != "Linux" ]]; then
  echo "ERROR: this package must be verified and installed on Linux" >&2
  exit 1
fi

arch=$(uname -m)
if [[ "$arch" != "x86_64" ]]; then
  echo "ERROR: unsupported architecture: $arch (expected x86_64)" >&2
  exit 1
fi

glibc_line=$(getconf GNU_LIBC_VERSION 2>/dev/null || true)
glibc_version=${glibc_line#glibc }
if [[ -z "$glibc_line" || "$glibc_version" == "$glibc_line" ]]; then
  echo "ERROR: GNU glibc was not detected" >&2
  exit 1
fi

minimum_glibc=2.17
oldest=$(printf '%s\n%s\n' "$minimum_glibc" "$glibc_version" | sort -V | head -n 1)
if [[ "$oldest" != "$minimum_glibc" ]]; then
  echo "ERROR: glibc $glibc_version is too old; glibc $minimum_glibc or newer is required" >&2
  exit 1
fi

command -v sha256sum >/dev/null || {
  echo "ERROR: sha256sum is required" >&2
  exit 1
}
command -v tar >/dev/null || {
  echo "ERROR: tar is required" >&2
  exit 1
}

sha256sum -c SHA256SUMS
payload="payload/cpython-3.10.21+20260901-x86_64-unknown-linux-gnu-install_only.tar.gz"
archive_list=$(mktemp)
trap 'rm -f -- "$archive_list"' EXIT
tar -tzf "$payload" >"$archive_list"
grep -Fxq 'python/bin/python3.10' "$archive_list"
grep -Fxq 'python/bin/pip3.10' "$archive_list"
grep -Fxq 'python/lib/libpython3.10.so.1.0' "$archive_list"

echo "Platform check: Linux x86_64, glibc $glibc_version"
echo "Offline package verification: OK"
